
export const environment = {
  production: false,
  REST_BASE_API: "http://localhost:3000/api"
};
