If I have more time: I can do all tasks.

1. Clickable and getting detail
2. Delete
